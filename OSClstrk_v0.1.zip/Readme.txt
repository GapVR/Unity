OSClstrk v0.1 20240603
https://github.com/GapVR

=====

(日本語)

OSClstrk.exe

OSClstrkは、SteamVRコントローラー/トラッカーのトラッキングロスト状態を
OSCで「OSClstrk」のアバターパラメーターにintのパケットを通信する
コマンドラインプログラムです。

使用方法:
- SteamVRが起動中にいつでも起動と停止するできます
- 終了する際に、OSClstrkはOSCで0に設定されてます

パラメーター:
- OSClstrk.exe <ミリ秒> : 状態更新とOSCパケット通信のインターバル (デフォルト: 200)

--

OSClstrk-MA-LHRH.unitypackage
(Modular Avatar必要)

コントローラーのトラッキングロストしたの場合、左/右腕をアニメーションに切り替えます

導入方法:
-　OSClstrk.prefabをアバターに入れ込みます

使用方法:
- SteamVRが起動中にOSClstrk.exeを起動します（ダブルクリック）


=====

(English)

OSClstrk.exe

OSClstrk is a command-line program that
- sends an OSC int packet to the 'OSClstrk' avatar parameter
- with the state of SteamVR controller/tracker devices with lost tracking.

Usage:
- Run OSClstrk.exe when SteamVR is running.
- The program can be started and stopped at any time.
- OSClstrk will be set to 0 before terminating.

Options:
- OSClstrk.exe <miliseconds> : update/OSC packet interval (default: 200)

---

OSClstrk-MA-LHRH.unitypackage
(Requires Modular Avatar)

Switches left/right hand to animation when controller tracking is lost.
- Place the prefab in your avatar.
- Works only when OSClstrk.exe is running.


=====


OSC: /avatar/parameters/OSClstrk,int

Bit	Int	デバイス	Device

	0	無し	None

コントローラー/Controller:
0	1	左手	LeftHand
1	2	右手	RightHand

トラッカー/Tracker:
2	4	左足	LeftFoot
3	8	右足	RightFoot
4	16	左肩	LeftShoulder
5	32	右肩	RightShoulder
6	64	左肘	LeftElbow
7	128	右肘	RightElbow
8	256	左膝	LeftKnee
9	512	右膝	RightKnee
10	1024	腰	Waist
11	2048	胸	Chest
